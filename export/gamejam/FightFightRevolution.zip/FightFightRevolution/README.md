Fight Fight Revolution
by Hoani

I hope you enjoy this entry; it's been a wild ride getting this one put together in 4 days.

The game size is pretty huge... but that's actually because of the graphics.
All of the music is compressed, I promise :D

## Controls
This game is played with the keyboard.
WASD/Arrow keys + Enter/Space for menus
WASD/Arrow Keys are used for fighting - see in game controls for more info

Gamepad should work too - but I've only tested it on a 360 controller.


## Credits
I was squeezed for time on this entry, so I didn't try and make any music for this game. 
I also used some fonts online to get a comic-book look for the text.

See the in game credits for more details.



